<?php
$_GET['archive'] = 'category';
require_once 'blog.php';