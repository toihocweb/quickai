        <div id="welcome" class="step">
            <h1 class="page-title">QuickCMS Installation</h1>
            <p>
                Welcome! QuickCMS is an custom content management system developed by Bylancer developers.
            </p>
            <p class="fw-600 mb-40">
                Installation process is very easy and it takes less than 2 minutes!
            </p>

            <a href="javascript:void(0)" class="oval button next-btn" data-next="#agreement">Start Installation</a>
        </div>