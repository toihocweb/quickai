<?php
HtmlTemplate::display('global/404');
exit;